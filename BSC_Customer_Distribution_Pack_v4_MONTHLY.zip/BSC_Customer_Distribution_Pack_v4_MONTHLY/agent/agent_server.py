from __future__ import annotations
import asyncio, json, os, secrets, threading, time
from collections import deque
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn

from bsc_trader.config import default_config, validate_config
from bsc_trader.engine import TradingEngine
from bsc_trader.exchange import UniversalExchange
from bsc_trader.paths import app_data_dir, state_path
from bsc_trader.vault import save_credentials, load_credentials
from bsc_trader.license import device_id, current_license, activate_license_key

DATA = app_data_dir()
AGENT_SETTINGS = DATA/'agent_settings.json'
TOKEN_FILE = DATA/'agent_pairing_token.txt'

class Creds(BaseModel):
    exchange_id: str
    profile: str = 'main'
    api_key: str
    api_secret: str
    api_password: str = ''
class LicenseIn(BaseModel):
    license_key: str
class ConfigIn(BaseModel):
    exchange_id: str = 'bitget'
    profile: str = 'main'
    config: dict[str, Any]

class Manager:
    def __init__(self):
        self.thread = None; self.stop = threading.Event(); self.status = {'state':'STOPPED'}; self.logs = deque(maxlen=300)
        self.settings = self.load_settings()
    def load_settings(self):
        if AGENT_SETTINGS.exists():
            try: return json.loads(AGENT_SETTINGS.read_text())
            except Exception: pass
        return {'exchange_id':'bitget','profile':'main','config':default_config()}
    def save_settings(self): AGENT_SETTINGS.write_text(json.dumps(self.settings, indent=2), encoding='utf-8')
    def log(self, m): self.logs.append({'ts':int(time.time()),'message':str(m)})
    def set_status(self, d): self.status.update(d)
    def start(self):
        if self.thread and self.thread.is_alive(): return
        current_license(self.settings['config'].get('market_type','spot'), allow_cache=True)
        ex = self.settings['exchange_id']; profile = self.settings['profile']; cfg = self.settings['config']; validate_config(cfg); creds = load_credentials(ex, profile)
        self.stop.clear(); st = state_path(ex, profile, cfg['market_type'], cfg['symbol'])
        def worker():
            eng = TradingEngine(ex, creds, cfg, st, log=self.log, status=self.set_status)
            try: asyncio.run(eng.run(self.stop))
            except Exception as e: self.log(f'FATAL: {type(e).__name__}: {e}'); self.status={'state':'ERROR','message':str(e)}
            finally: self.status['state']='STOPPED'
        self.thread = threading.Thread(target=worker, daemon=True); self.thread.start(); self.status['state']='STARTING'
    def stop_bot(self): self.stop.set(); self.status['state']='STOPPING'

mgr = Manager()

def token():
    if not TOKEN_FILE.exists(): TOKEN_FILE.write_text(secrets.token_urlsafe(32), encoding='utf-8')
    return TOKEN_FILE.read_text().strip()
PAIRING_TOKEN = token()

app = FastAPI(title='BSC Bot Agent', version='3.0')
origins = [x.strip() for x in os.getenv('BSC_ALLOWED_ORIGINS','http://localhost,http://127.0.0.1').split(',') if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=['*'], allow_headers=['*'])

def auth(authorization: str | None):
    if authorization != f'Bearer {PAIRING_TOKEN}': raise HTTPException(401, 'Invalid pairing token.')

def secure_for_secrets(request: Request):
    host = request.client.host if request.client else ''
    forwarded = request.headers.get('x-forwarded-proto','')
    if request.url.scheme != 'https' and forwarded != 'https' and host not in ('127.0.0.1','::1','localhost'):
        raise HTTPException(400, 'API credentials can only be submitted over HTTPS or localhost.')

@app.get('/health')
def health(): return {'ok':True,'product':'BSC Bot Agent','device_id':device_id()}
@app.get('/api/pairing-info')
def pairing_info(authorization: str|None=Header(None)):
    auth(authorization); return {'device_id':device_id(),'license': _license_summary()}

def _license_summary():
    try:
        market=mgr.settings.get('config',{}).get('market_type','spot')
        x=current_license(market, allow_cache=True)
        return {'active':True,'product_code':x.get('product_code'),'expires_at':x.get('expires_at'),'cached':x.get('cached',False)}
    except Exception as e:
        return {'active':False,'error':str(e)}

@app.post('/api/license')
def install_license(body: LicenseIn, authorization: str|None=Header(None)):
    auth(authorization); return {'ok':True,'license':activate_license_key(body.license_key)}
@app.get('/api/status')
def status(authorization: str|None=Header(None)):
    auth(authorization); return {**mgr.status,'settings':mgr.settings,'license':_license_summary()}
@app.get('/api/logs')
def logs(authorization: str|None=Header(None)):
    auth(authorization); return list(mgr.logs)
@app.post('/api/config')
def config(body: ConfigIn, authorization: str|None=Header(None)):
    auth(authorization); validate_config(body.config); mgr.settings={'exchange_id':body.exchange_id.strip().lower(),'profile':body.profile.strip() or 'main','config':body.config}; mgr.save_settings(); return {'ok':True}
@app.post('/api/credentials')
def credentials(body: Creds, request: Request, authorization: str|None=Header(None)):
    auth(authorization); secure_for_secrets(request); save_credentials(body.exchange_id,body.profile,body.api_key,body.api_secret,body.api_password); return {'ok':True}
@app.post('/api/test-connection')
def test_connection(authorization: str|None=Header(None)):
    auth(authorization)
    ex=mgr.settings['exchange_id']; profile=mgr.settings['profile']; cfg=mgr.settings['config']; creds=load_credentials(ex,profile)
    ux=UniversalExchange(ex,creds,cfg)
    result=asyncio.run(ux.test_connection()); return result
@app.post('/api/start')
def start(authorization: str|None=Header(None)):
    auth(authorization)
    try: mgr.start(); return {'ok':True,'state':mgr.status.get('state')}
    except Exception as e: raise HTTPException(400,str(e))
@app.post('/api/stop')
def stop(authorization: str|None=Header(None)):
    auth(authorization); mgr.stop_bot(); return {'ok':True,'state':'STOPPING'}

MOBILE_DIR = Path(__file__).with_name('mobile_www')
if MOBILE_DIR.exists():
    app.mount('/mobile', StaticFiles(directory=str(MOBILE_DIR), html=True), name='mobile')

if __name__ == '__main__':
    host=os.getenv('BSC_AGENT_HOST','127.0.0.1'); port=int(os.getenv('BSC_AGENT_PORT','8765'))
    print('BSC Agent device ID:', device_id())
    print('BSC Agent pairing token:', PAIRING_TOKEN)
    print(f'Listening on http://{host}:{port}')
    uvicorn.run(app, host=host, port=port)
