#!/usr/bin/env bash
set -e
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export BSC_AGENT_HOST=${BSC_AGENT_HOST:-0.0.0.0}
python agent_server.py
