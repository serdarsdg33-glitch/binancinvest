@echo off
py -m pip install -r requirements.txt
set BSC_AGENT_HOST=0.0.0.0
py agent_server.py
pause
