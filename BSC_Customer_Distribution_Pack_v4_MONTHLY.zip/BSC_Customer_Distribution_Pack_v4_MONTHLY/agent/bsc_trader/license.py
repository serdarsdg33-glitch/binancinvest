from __future__ import annotations
import hashlib, json, os, platform, socket, uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib import request, error
import keyring
from .paths import app_data_dir

LICENSE_ENDPOINT = "https://zpwxvngrowhqquwpovuf.supabase.co/functions/v1/bsc-license-check"
SERVICE = "BSC Universal Trading Bot"
KEY_NAME = "monthly_subscription_license"
CACHE_HOURS = 6

class LicenseRejected(RuntimeError):
    pass

class LicenseNetworkError(RuntimeError):
    pass

def device_id() -> str:
    parts = [platform.system(), platform.machine(), socket.gethostname(), str(uuid.getnode())]
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as k:
                parts.append(str(winreg.QueryValueEx(k, "MachineGuid")[0]))
        except Exception:
            pass
    else:
        for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try:
                val = Path(p).read_text().strip()
                if val:
                    parts.append(val)
                    break
            except Exception:
                pass
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:32].upper()

def cache_path() -> Path:
    return app_data_dir() / "bsc_subscription_cache.json"

def saved_license_key(mask: bool = False) -> str:
    key = (keyring.get_password(SERVICE, KEY_NAME) or "").strip().upper()
    if mask and key:
        return key[:12] + "••••••••" + key[-8:]
    return key

def save_license_key(key: str) -> str:
    value = str(key or "").strip().upper()
    if not revalidate_key_format(value):
        raise RuntimeError("Invalid BSC License Key format.")
    keyring.set_password(SERVICE, KEY_NAME, value)
    return value

def revalidate_key_format(value: str) -> bool:
    import re
    return bool(re.fullmatch(r"BSC-[A-F0-9]{8}(?:-[A-F0-9]{8}){5}", value or ""))

def clear_license_key() -> None:
    try:
        keyring.delete_password(SERVICE, KEY_NAME)
    except Exception:
        pass
    cache_path().unlink(missing_ok=True)

def _parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc)

def _server_check(key: str, market_type: str) -> dict:
    payload = json.dumps({
        "license_key": key,
        "device_id": device_id(),
        "market_type": market_type,
    }).encode("utf-8")
    req = request.Request(
        LICENSE_ENDPOINT,
        data=payload,
        method="POST",
        headers={"Content-Type": "application/json", "User-Agent": "BSC-Trading-Bot/4.0"},
    )
    try:
        with request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except error.HTTPError as e:
        try:
            data = json.loads(e.read().decode("utf-8"))
            code = data.get("error") or f"HTTP {e.code}"
        except Exception:
            code = f"HTTP {e.code}"
        messages = {
            "subscription_expired": "BSC subscription has expired. Renew it on BinancInvest.",
            "device_mismatch": "This license is activated on another device.",
            "product_not_entitled": "This subscription does not include the selected Spot/Futures mode.",
            "license_invalid": "BSC License Key is invalid or revoked.",
            "subscription_missing": "No active BSC subscription was found.",
        }
        raise LicenseRejected(messages.get(code, f"License rejected: {code}"))
    except (error.URLError, TimeoutError, OSError) as e:
        raise LicenseNetworkError("Could not reach the BSC license server.") from e
    if not data.get("active"):
        raise LicenseRejected(str(data.get("error") or "BSC subscription is not active."))
    exp = _parse_iso(data["expires_at"])
    if datetime.now(timezone.utc) >= exp:
        raise LicenseRejected("BSC subscription has expired. Renew it on BinancInvest.")
    return data

def _save_cache(data: dict, market_type: str) -> None:
    payload = {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "market_type": market_type,
        "license": data,
    }
    cache_path().write_text(json.dumps(payload, indent=2), encoding="utf-8")

def _cached_license(market_type: str) -> dict:
    p = cache_path()
    if not p.exists():
        raise LicenseNetworkError("No recent online license check is available.")
    data = json.loads(p.read_text(encoding="utf-8"))
    checked = _parse_iso(data["checked_at"])
    if datetime.now(timezone.utc) - checked > timedelta(hours=CACHE_HOURS):
        raise LicenseNetworkError("Internet connection is required to refresh the BSC subscription.")
    lic = data.get("license") or {}
    if market_type != "activate" and data.get("market_type") not in (market_type, "activate"):
        raise LicenseNetworkError("This market mode needs a fresh license check.")
    if datetime.now(timezone.utc) >= _parse_iso(lic.get("expires_at")):
        raise LicenseRejected("BSC subscription has expired. Renew it on BinancInvest.")
    if not lic.get("active"):
        raise LicenseRejected("BSC subscription is not active.")
    return {**lic, "cached": True}

def activate_license_key(key: str) -> dict:
    value = save_license_key(key)
    data = _server_check(value, "activate")
    _save_cache(data, "activate")
    return data

def current_license(market_type: str = "spot", allow_cache: bool = True) -> dict:
    key = saved_license_key()
    if not key:
        raise RuntimeError(f"No BSC License Key saved. Device ID: {device_id()}")
    market = "swap" if str(market_type).lower() in ("swap", "futures") else "spot"
    try:
        data = _server_check(key, market)
        _save_cache(data, market)
        return data
    except LicenseNetworkError:
        if allow_cache:
            return _cached_license(market)
        raise
