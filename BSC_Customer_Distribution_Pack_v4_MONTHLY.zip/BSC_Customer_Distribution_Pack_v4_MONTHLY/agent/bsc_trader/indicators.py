\
from __future__ import annotations
import numpy as np
import pandas as pd

def ema(s: pd.Series, length: int) -> pd.Series:
    return s.ewm(span=length, adjust=False).mean()

def rsi(s: pd.Series, length: int = 14) -> pd.Series:
    delta = s.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1/length, adjust=False, min_periods=length).mean()
    avg_loss = loss.ewm(alpha=1/length, adjust=False, min_periods=length).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return (100 - 100 / (1 + rs)).fillna(50)

def true_range(df: pd.DataFrame) -> pd.Series:
    prev_close = df["close"].shift(1)
    return pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)

def atr(df: pd.DataFrame, length: int = 14) -> pd.Series:
    return true_range(df).ewm(alpha=1/length, adjust=False, min_periods=length).mean()

def adx(df: pd.DataFrame, length: int = 14) -> pd.Series:
    up = df["high"].diff()
    down = -df["low"].diff()
    plus_dm = pd.Series(np.where((up > down) & (up > 0), up, 0.0), index=df.index)
    minus_dm = pd.Series(np.where((down > up) & (down > 0), down, 0.0), index=df.index)
    tr = true_range(df)
    atr_w = tr.ewm(alpha=1/length, adjust=False, min_periods=length).mean()
    plus_di = 100 * plus_dm.ewm(alpha=1/length, adjust=False, min_periods=length).mean() / atr_w
    minus_di = 100 * minus_dm.ewm(alpha=1/length, adjust=False, min_periods=length).mean() / atr_w
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    return dx.ewm(alpha=1/length, adjust=False, min_periods=length).mean().fillna(0)

def enrich(df: pd.DataFrame, s: dict) -> pd.DataFrame:
    out = df.copy()
    out["ema_fast"] = ema(out["close"], int(s["ema_fast"]))
    out["ema_slow"] = ema(out["close"], int(s["ema_slow"]))
    out["rsi"] = rsi(out["close"], int(s["rsi_period"]))
    out["atr"] = atr(out, int(s["atr_period"]))
    out["adx"] = adx(out, int(s["adx_period"]))
    out["vol_ma"] = out["volume"].rolling(int(s["volume_ma"])).mean()
    out["vol_ratio"] = out["volume"] / out["vol_ma"].replace(0, np.nan)
    return out
