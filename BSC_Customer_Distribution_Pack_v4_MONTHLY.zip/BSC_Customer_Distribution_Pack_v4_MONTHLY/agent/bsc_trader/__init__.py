APP_NAME = "BSC Universal Trading Bot"
APP_VERSION = "2.0.0"
