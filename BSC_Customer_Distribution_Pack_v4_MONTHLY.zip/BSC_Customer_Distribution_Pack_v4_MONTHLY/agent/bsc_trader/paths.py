\
from pathlib import Path
import os
import re

def app_data_dir() -> Path:
    override = os.getenv('BSC_DATA_DIR','').strip()
    if override:
        p = Path(override); p.mkdir(parents=True, exist_ok=True); return p
    if os.name == "nt":
        base = Path(os.getenv("APPDATA") or Path.home())
    else:
        base = Path.home() / ".config"
    p = base / "BSCTradingBot"
    p.mkdir(parents=True, exist_ok=True)
    return p

def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip())[:80] or "default"

def state_path(exchange_id: str, profile: str, market_type: str, symbol: str) -> Path:
    name = "__".join(map(safe_name, [exchange_id, profile, market_type, symbol]))
    p = app_data_dir() / "state"
    p.mkdir(parents=True, exist_ok=True)
    return p / f"{name}.json"

def settings_path() -> Path:
    return app_data_dir() / "ui_settings.json"
