\
from __future__ import annotations
import asyncio
import time
from pathlib import Path
from typing import Callable

from .exchange import UniversalExchange
from .risk import calc_base_amount, daily_loss_hit
from .state import Position, load_state, save_state
from .strategy import TrendStrategy
from .license import current_license

LogFn = Callable[[str], None]
StatusFn = Callable[[dict], None]

class TradingEngine:
    def __init__(
        self,
        exchange_id: str,
        credentials: dict,
        cfg: dict,
        state_file: Path,
        log: LogFn | None = None,
        status: StatusFn | None = None,
    ):
        self.exchange_id = exchange_id
        self.credentials = credentials
        self.cfg = cfg
        self.state_file = state_file
        self.log = log or (lambda _: None)
        self.status = status or (lambda _: None)
        self.ux = UniversalExchange(exchange_id, credentials, cfg)
        self.strategy = TrendStrategy(cfg)
        self.state = None
        self._last_idle_log = 0.0
        self._license_last_check = 0.0
        self._license_ok = True
        self._license_error = ""

    async def run(self, stop_flag) -> None:
        await self.ux.connect()
        try:
            price = await self.ux.ticker_price()
            snap = await self.ux.account_snapshot(price)
            if snap["equity"] <= 0:
                raise RuntimeError("No positive account equity was detected.")

            self.state = load_state(self.state_file, snap["equity"])
            await self._startup_reconcile()

            self.log(
                f"LIVE connected: {self.ux.ex.id.upper()} | "
                f"{self.cfg['market_type'].upper()} | {self.cfg['symbol']}"
            )
            self._emit_status(price, snap, "RUNNING")

            while not stop_flag.is_set():
                try:
                    await self.tick()
                except Exception as e:
                    self.log(f"ERROR: {type(e).__name__}: {e}")
                    self.status({"state": "ERROR", "message": str(e)})
                    await asyncio.sleep(min(10.0, float(self.cfg["poll_seconds"]) * 2))
                await asyncio.sleep(float(self.cfg["poll_seconds"]))
        finally:
            self.status({"state": "STOPPED"})
            await self.ux.close()

    async def _startup_reconcile(self) -> None:
        if self.cfg["market_type"] == "spot":
            return
        live = await self.ux.derivative_positions()
        if live and self.state.position is None:
            raise RuntimeError(
                "There is already an unmanaged live futures position on this symbol. "
                "The bot refuses to trade over it."
            )
        if not live and self.state.position is not None:
            self.log("SAFE: stale local futures state cleared.")
            self.state.position = None
            save_state(self.state_file, self.state)

    async def _refresh_license_if_due(self) -> None:
        now = time.time()
        if now - self._license_last_check < 600:
            return
        self._license_last_check = now
        try:
            info = await asyncio.to_thread(current_license, self.cfg["market_type"], True)
            was_blocked = not self._license_ok
            self._license_ok = True
            self._license_error = ""
            self.status({"license_state": "ACTIVE", "license_expires_at": info.get("expires_at")})
            if was_blocked:
                self.log("LICENSE: subscription active again. New entries are enabled.")
        except Exception as e:
            self._license_ok = False
            self._license_error = str(e)
            self.status({"license_state": "BLOCKED", "message": self._license_error})
            self.log(f"LICENSE: {self._license_error}")

    async def tick(self) -> None:
        await self._refresh_license_if_due()
        price = await self.ux.ticker_price()
        snap = await self.ux.account_snapshot(price)
        self._emit_status(price, snap, "RUNNING")

        # If a position is already open, keep managing its risk even after expiry.
        if self.state.position is not None:
            await self.manage_position(price)
            return

        # Expired/revoked subscription blocks NEW entries, but never abandons an open position.
        if not self._license_ok:
            return

        if daily_loss_hit(self.state, self.cfg):
            now = time.time()
            if now - self._last_idle_log > 30:
                self.log("RISK: daily loss limit reached. New entries are blocked.")
                self._last_idle_log = now
            return

        if int(time.time() * 1000) < self.state.cooldown_until_ms:
            return

        candles = await self.ux.ohlcv(int(self.cfg["ohlcv_limit"]))
        signal = self.strategy.evaluate(candles)

        self.status({
            "signal": signal.reason,
            "rsi": round(signal.rsi, 2),
            "adx": round(signal.adx, 2),
        })

        if not signal.side:
            return
        if signal.candle_ts <= self.state.last_signal_candle_ts:
            return

        self.state.last_signal_candle_ts = signal.candle_ts
        save_state(self.state_file, self.state)
        await self.open_position(signal.side, price, signal.atr, snap)

    async def open_position(self, side: str, entry: float, atr: float, snap: dict) -> None:
        if atr <= 0:
            return

        stop_atr = float(self.cfg["stop_atr"])
        rr = float(self.cfg["take_profit_rr"])

        if side == "buy":
            stop = entry - atr * stop_atr
            take_profit = entry + (entry - stop) * rr
        else:
            stop = entry + atr * stop_atr
            take_profit = entry - (stop - entry) * rr

        base_amount = calc_base_amount(
            self.cfg,
            snap["equity"],
            snap["quote_free"],
            entry,
            stop,
        )
        amount = self.ux.amount_from_base(base_amount)
        if amount <= 0:
            raise RuntimeError("Calculated order amount is zero.")
        self.ux.validate_amount(amount, entry)

        order = await self.ux.market_order(side, amount, reduce_only=False)
        fill = await self.ux.resolve_fill_price(order, entry)

        if side == "buy":
            stop = fill - atr * stop_atr
            take_profit = fill + (fill - stop) * rr
            trailing = fill - atr * float(self.cfg["trailing_atr"])
        else:
            stop = fill + atr * stop_atr
            take_profit = fill - (stop - fill) * rr
            trailing = fill + atr * float(self.cfg["trailing_atr"])

        self.state.position = Position(
            side=side,
            amount=amount,
            entry=fill,
            stop=stop,
            take_profit=take_profit,
            trailing_stop=trailing,
            highest=fill,
            lowest=fill,
            order_id=str(order.get("id") or ""),
        )
        save_state(self.state_file, self.state)

        self.log(
            f"OPEN {side.upper()} | amount={amount} | entry≈{fill:.8f} | "
            f"SL={stop:.8f} | TP={take_profit:.8f}"
        )
        self.status({"position": side.upper(), "entry": fill, "sl": stop, "tp": take_profit})

    async def manage_position(self, price: float) -> None:
        p = self.state.position
        if p is None:
            return

        # Reconcile before placing an exit order.
        if self.cfg["market_type"] == "spot":
            snap = await self.ux.account_snapshot(price)
            expected_base = self.ux.base_units(p.amount)
            if snap["base_total"] < expected_base * 0.90:
                self.log("SAFE: spot balance no longer matches bot state. Local position cleared.")
                self.state.position = None
                save_state(self.state_file, self.state)
                return
        else:
            live = await self.ux.derivative_positions()
            if not live:
                self.log("SAFE: live futures position is gone. Local state cleared.")
                self.state.position = None
                save_state(self.state_file, self.state)
                return
            expected_side = "long" if p.side == "buy" else "short"
            sides = {str(x.get("side") or "").lower() for x in live}
            if sides and expected_side not in sides:
                raise RuntimeError(
                    f"Live position direction {sides} conflicts with bot state {expected_side}."
                )

        trail_distance = abs(p.entry - p.trailing_stop)

        if p.side == "buy":
            p.highest = max(p.highest, price)
            p.trailing_stop = max(p.trailing_stop, p.highest - trail_distance)
            active_stop = max(p.stop, p.trailing_stop)
            if price <= active_stop:
                await self.close_position(price, "STOP/TRAIL")
                return
            if price >= p.take_profit:
                await self.close_position(price, "TAKE PROFIT")
                return
        else:
            p.lowest = min(p.lowest, price)
            p.trailing_stop = min(p.trailing_stop, p.lowest + trail_distance)
            active_stop = min(p.stop, p.trailing_stop)
            if price >= active_stop:
                await self.close_position(price, "STOP/TRAIL")
                return
            if price <= p.take_profit:
                await self.close_position(price, "TAKE PROFIT")
                return

        save_state(self.state_file, self.state)
        self.status({
            "position": p.side.upper(),
            "entry": p.entry,
            "sl": p.stop,
            "tp": p.take_profit,
            "trail": p.trailing_stop,
        })

    async def close_position(self, price: float, reason: str) -> None:
        p = self.state.position
        if p is None:
            return

        side = "sell" if p.side == "buy" else "buy"
        order = await self.ux.market_order(
            side,
            p.amount,
            reduce_only=self.cfg["market_type"] != "spot",
        )
        fill = await self.ux.resolve_fill_price(order, price)
        units = self.ux.base_units(p.amount)

        if p.side == "buy":
            pnl = (fill - p.entry) * units
        else:
            pnl = (p.entry - fill) * units

        self.state.realized_pnl_today += pnl
        if pnl < 0:
            self.state.consecutive_losses += 1
        else:
            self.state.consecutive_losses = 0

        if self.state.consecutive_losses >= int(self.cfg["max_consecutive_losses"]):
            mins = int(self.cfg["loss_cooldown_minutes"])
            self.state.cooldown_until_ms = int(time.time() * 1000) + mins * 60_000
            self.state.consecutive_losses = 0
            self.log(f"RISK: cooldown enabled for {mins} minutes.")

        self.state.position = None
        save_state(self.state_file, self.state)

        self.log(
            f"CLOSE {reason} | exit≈{fill:.8f} | "
            f"PnL≈{pnl:.4f} {self.ux.market['quote']} | "
            f"daily≈{self.state.realized_pnl_today:.4f}"
        )
        self.status({"position": "NONE", "last_pnl": pnl})

    def _emit_status(self, price: float, snap: dict, state: str) -> None:
        self.status({
            "state": state,
            "price": price,
            "equity": snap["equity"],
            "quote": snap["quote"],
            "daily_pnl": self.state.realized_pnl_today if self.state else 0.0,
            "position": (
                self.state.position.side.upper()
                if self.state and self.state.position else "NONE"
            ),
        })
