from __future__ import annotations
import json, os
from pathlib import Path
from cryptography.fernet import Fernet
from .paths import app_data_dir

SERVICE = 'BSC Universal Trading Bot'

def _name(exchange_id: str, profile: str) -> str:
    return f'{exchange_id.strip().lower()}::{profile.strip() or "main"}'

def _file_paths():
    d = app_data_dir(); return d/'agent_vault.key', d/'agent_vault.json.enc'

def _fernet():
    k, _ = _file_paths()
    if not k.exists():
        k.write_bytes(Fernet.generate_key())
        try: os.chmod(k, 0o600)
        except Exception: pass
    return Fernet(k.read_bytes())

def _load_all() -> dict:
    _, p = _file_paths()
    if not p.exists(): return {}
    try: return json.loads(_fernet().decrypt(p.read_bytes()).decode())
    except Exception as e: raise RuntimeError('Credential vault could not be decrypted.') from e

def _save_all(data: dict):
    _, p = _file_paths(); p.write_bytes(_fernet().encrypt(json.dumps(data).encode()))
    try: os.chmod(p, 0o600)
    except Exception: pass

def save_credentials(exchange_id, profile, api_key, api_secret, api_password=''):
    if not api_key or not api_secret: raise ValueError('API key/secret required.')
    data = _load_all(); data[_name(exchange_id, profile)] = {'api_key':api_key.strip(),'api_secret':api_secret.strip(),'api_password':api_password.strip()}; _save_all(data)

def load_credentials(exchange_id, profile):
    data = _load_all(); item = data.get(_name(exchange_id, profile))
    if not item: raise RuntimeError('No saved credentials for this exchange/profile.')
    return item

def delete_credentials(exchange_id, profile):
    data = _load_all(); ok = data.pop(_name(exchange_id, profile), None) is not None; _save_all(data); return ok
