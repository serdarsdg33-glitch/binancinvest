\
from __future__ import annotations

def calc_base_amount(cfg: dict, equity: float, available_quote: float, entry: float, stop: float) -> float:
    risk_budget = equity * (float(cfg["risk_per_trade_pct"]) / 100.0)
    stop_distance = abs(entry - stop)
    if stop_distance <= 0:
        raise RuntimeError("Invalid stop distance.")
    base_by_risk = risk_budget / stop_distance

    if cfg["market_type"] == "spot":
        cap_quote = min(
            available_quote,
            equity * (float(cfg["max_position_pct"]) / 100.0)
        )
        base_by_cap = cap_quote / entry
    else:
        leverage = max(1.0, float(cfg["leverage"]))
        margin_cap = equity * (float(cfg["max_margin_pct"]) / 100.0)
        base_by_cap = (margin_cap * leverage) / entry

    return max(0.0, min(base_by_risk, base_by_cap))

def daily_loss_hit(state, cfg: dict) -> bool:
    limit = state.day_start_equity * (float(cfg["max_daily_loss_pct"]) / 100.0)
    return state.realized_pnl_today <= -limit
