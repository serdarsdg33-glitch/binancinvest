\
from __future__ import annotations
from dataclasses import dataclass
import pandas as pd
from .indicators import enrich

@dataclass
class Signal:
    side: str | None
    reason: str
    atr: float
    candle_ts: int
    rsi: float = 0.0
    adx: float = 0.0

class TrendStrategy:
    def __init__(self, cfg: dict):
        self.cfg = cfg

    def evaluate(self, raw: pd.DataFrame) -> Signal:
        s = self.cfg["strategy"]
        df = enrich(raw, s).dropna()
        if len(df) < 3:
            return Signal(None, "not_enough_data", 0.0, 0)

        # Only use a CLOSED candle.
        row = df.iloc[-2]
        prev = df.iloc[-3]
        atr_value = float(row["atr"])
        ts = int(row["timestamp"])
        rsi_value = float(row["rsi"])
        adx_value = float(row["adx"])

        volume_ok = float(row["vol_ratio"]) >= float(s["min_volume_ratio"])
        trend_ok = adx_value >= float(s["min_adx"])

        long_ok = (
            volume_ok and trend_ok
            and row["ema_fast"] > row["ema_slow"]
            and float(s["rsi_long_min"]) <= rsi_value <= float(s["rsi_long_max"])
            and row["close"] > row["ema_fast"]
            and row["ema_fast"] >= prev["ema_fast"]
        )
        if long_ok:
            return Signal("buy", "trend_long", atr_value, ts, rsi_value, adx_value)

        if self.cfg["market_type"] != "spot":
            short_ok = (
                volume_ok and trend_ok
                and row["ema_fast"] < row["ema_slow"]
                and float(s["rsi_short_min"]) <= rsi_value <= float(s["rsi_short_max"])
                and row["close"] < row["ema_fast"]
                and row["ema_fast"] <= prev["ema_fast"]
            )
            if short_ok:
                return Signal("sell", "trend_short", atr_value, ts, rsi_value, adx_value)

        return Signal(None, "no_signal", atr_value, ts, rsi_value, adx_value)
