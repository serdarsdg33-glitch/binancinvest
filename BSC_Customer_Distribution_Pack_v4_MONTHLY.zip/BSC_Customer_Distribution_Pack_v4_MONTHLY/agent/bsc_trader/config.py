\
from __future__ import annotations

def default_config() -> dict:
    return {
        "market_type": "spot",
        "symbol": "BTC/USDT",
        "timeframe": "15m",
        "ohlcv_limit": 250,
        "poll_seconds": 4,
        "risk_per_trade_pct": 0.35,
        "max_daily_loss_pct": 2.0,
        "max_position_pct": 20.0,
        "max_margin_pct": 12.0,
        "leverage": 3,
        "margin_mode": "isolated",
        "stop_atr": 1.8,
        "take_profit_rr": 2.2,
        "trailing_atr": 1.4,
        "max_consecutive_losses": 3,
        "loss_cooldown_minutes": 90,
        "strategy": {
            "ema_fast": 20,
            "ema_slow": 50,
            "rsi_period": 14,
            "atr_period": 14,
            "adx_period": 14,
            "min_adx": 18,
            "rsi_long_min": 52,
            "rsi_long_max": 72,
            "rsi_short_min": 28,
            "rsi_short_max": 48,
            "volume_ma": 20,
            "min_volume_ratio": 0.80,
        },
    }

def validate_config(cfg: dict) -> None:
    if cfg["market_type"] not in ("spot", "swap"):
        raise ValueError("Market type must be spot or swap.")
    if not cfg["symbol"].strip():
        raise ValueError("Symbol is required.")
    if float(cfg["risk_per_trade_pct"]) <= 0 or float(cfg["risk_per_trade_pct"]) > 5:
        raise ValueError("Risk per trade must be between 0 and 5%.")
    if float(cfg["max_daily_loss_pct"]) <= 0 or float(cfg["max_daily_loss_pct"]) > 20:
        raise ValueError("Daily loss limit must be between 0 and 20%.")
    if int(cfg["leverage"]) < 1 or int(cfg["leverage"]) > 50:
        raise ValueError("Leverage must be between 1 and 50.")
    if int(cfg["strategy"]["ema_fast"]) >= int(cfg["strategy"]["ema_slow"]):
        raise ValueError("EMA Fast must be smaller than EMA Slow.")
