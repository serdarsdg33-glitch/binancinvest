\
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import json

@dataclass
class Position:
    side: str
    amount: float
    entry: float
    stop: float
    take_profit: float
    trailing_stop: float
    highest: float
    lowest: float
    order_id: str = ""

@dataclass
class BotState:
    day: str
    day_start_equity: float
    realized_pnl_today: float = 0.0
    consecutive_losses: int = 0
    cooldown_until_ms: int = 0
    last_signal_candle_ts: int = 0
    position: Position | None = None

def utc_day() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def load_state(path: Path, equity: float) -> BotState:
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("position"):
            data["position"] = Position(**data["position"])
        state = BotState(**data)
        if state.day != utc_day():
            state.day = utc_day()
            state.day_start_equity = equity
            state.realized_pnl_today = 0.0
            state.consecutive_losses = 0
        return state
    return BotState(day=utc_day(), day_start_equity=equity)

def save_state(path: Path, state: BotState) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(asdict(state), indent=2), encoding="utf-8")
