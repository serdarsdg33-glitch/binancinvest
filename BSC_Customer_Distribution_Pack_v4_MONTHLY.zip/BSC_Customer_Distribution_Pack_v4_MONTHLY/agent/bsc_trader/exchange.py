\
from __future__ import annotations
from typing import Any
import asyncio
import ccxt.async_support as ccxt
import pandas as pd

class UniversalExchange:
    def __init__(self, exchange_id: str, credentials: dict, cfg: dict):
        exchange_id = exchange_id.strip().lower()
        if not hasattr(ccxt, exchange_id):
            raise RuntimeError(f"Unknown CCXT exchange id: {exchange_id}")

        klass = getattr(ccxt, exchange_id)
        params: dict[str, Any] = {
            "apiKey": credentials["api_key"],
            "secret": credentials["api_secret"],
            "enableRateLimit": True,
            "options": {
                "defaultType": cfg["market_type"],
                "adjustForTimeDifference": True,
            },
        }
        if credentials.get("api_password"):
            params["password"] = credentials["api_password"]

        self.ex = klass(params)
        self.cfg = cfg
        self.symbol = cfg["symbol"]
        self.market = None

    async def connect(self) -> None:
        await self.ex.load_markets()
        if self.symbol not in self.ex.markets:
            base = self.symbol.split(":")[0]
            matches = [s for s in self.ex.symbols if base in s][:12]
            raise RuntimeError(
                f"Symbol {self.symbol} is not available on {self.ex.id}. "
                f"Possible matches: {', '.join(matches) if matches else 'none'}"
            )
        self.market = self.ex.market(self.symbol)

        for method in ("fetchOHLCV", "fetchBalance", "createOrder"):
            if not self.ex.has.get(method):
                raise RuntimeError(f"{self.ex.id} does not support required method: {method}")

        if self.cfg["market_type"] != "spot":
            margin_mode = self.cfg.get("margin_mode", "isolated")
            leverage = int(self.cfg.get("leverage", 1))
            if self.ex.has.get("setMarginMode"):
                try:
                    await self.ex.set_margin_mode(margin_mode, self.symbol)
                except Exception:
                    pass
            if self.ex.has.get("setLeverage"):
                try:
                    await self.ex.set_leverage(leverage, self.symbol)
                except Exception:
                    pass

    async def close(self) -> None:
        await self.ex.close()

    async def ohlcv(self, limit: int) -> pd.DataFrame:
        rows = await self.ex.fetch_ohlcv(
            self.symbol, timeframe=self.cfg["timeframe"], limit=limit
        )
        if not rows or len(rows) < 30:
            raise RuntimeError("Exchange returned insufficient OHLCV data.")
        return pd.DataFrame(
            rows, columns=["timestamp", "open", "high", "low", "close", "volume"]
        )

    async def ticker_price(self) -> float:
        t = await self.ex.fetch_ticker(self.symbol)
        px = t.get("last") or t.get("close")
        if px is None:
            raise RuntimeError("Ticker has no current price.")
        return float(px)

    async def balance(self) -> dict:
        return await self.ex.fetch_balance()

    async def account_snapshot(self, price: float) -> dict:
        bal = await self.balance()
        quote = self.market["quote"]
        base = self.market["base"]
        quote_obj = bal.get(quote) or {}
        base_obj = bal.get(base) or {}

        quote_total = float(quote_obj.get("total") or 0.0)
        quote_free = float(quote_obj.get("free") or 0.0)
        base_total = float(base_obj.get("total") or 0.0)

        if self.cfg["market_type"] == "spot":
            equity = quote_total + base_total * price
        else:
            equity = quote_total
            if equity <= 0:
                total = bal.get("total") or {}
                equity = float(total.get(quote) or 0.0)
            quote_free = max(quote_free, equity)

        return {
            "equity": equity,
            "quote_free": quote_free,
            "quote": quote,
            "base": base,
            "base_total": base_total,
        }

    def amount_from_base(self, base_amount: float) -> float:
        amount = base_amount
        if self.market.get("contract"):
            contract_size = float(self.market.get("contractSize") or 1.0)
            amount = base_amount / contract_size
        return float(self.ex.amount_to_precision(self.symbol, amount))

    def base_units(self, amount: float) -> float:
        if self.market.get("contract"):
            return amount * float(self.market.get("contractSize") or 1.0)
        return amount

    def validate_amount(self, amount: float, price: float) -> None:
        limits = self.market.get("limits") or {}
        min_amount = (limits.get("amount") or {}).get("min")
        min_cost = (limits.get("cost") or {}).get("min")
        if min_amount is not None and amount < float(min_amount):
            raise RuntimeError(f"Order amount {amount} is below minimum {min_amount}.")
        if min_cost is not None:
            notional = self.base_units(amount) * price
            if notional < float(min_cost):
                raise RuntimeError(f"Order notional {notional:.4f} is below minimum {min_cost}.")

    async def market_order(self, side: str, amount: float, reduce_only: bool = False) -> dict:
        if not self.ex.has.get("createMarketOrder"):
            raise RuntimeError(f"{self.ex.id} does not support unified market orders.")
        params: dict[str, Any] = {}
        if self.cfg["market_type"] != "spot":
            params["marginMode"] = self.cfg.get("margin_mode", "isolated")
            if reduce_only:
                params["reduceOnly"] = True
        return await self.ex.create_order(self.symbol, "market", side, amount, None, params)

    async def resolve_fill_price(self, order: dict, fallback: float) -> float:
        avg = order.get("average") or order.get("price")
        if avg:
            return float(avg)
        oid = order.get("id")
        if oid and self.ex.has.get("fetchOrder"):
            for _ in range(4):
                try:
                    await asyncio.sleep(0.65)
                    fresh = await self.ex.fetch_order(oid, self.symbol)
                    avg = fresh.get("average") or fresh.get("price")
                    if avg:
                        return float(avg)
                except Exception:
                    break
        return fallback

    async def derivative_positions(self) -> list[dict]:
        if self.cfg["market_type"] == "spot":
            return []
        positions = []
        if self.ex.has.get("fetchPosition"):
            p = await self.ex.fetch_position(self.symbol)
            positions = [p] if p else []
        elif self.ex.has.get("fetchPositions"):
            positions = await self.ex.fetch_positions([self.symbol])
        out = []
        for p in positions or []:
            contracts = float(p.get("contracts") or 0.0)
            if contracts > 0:
                out.append(p)
        return out

    async def test_connection(self) -> dict:
        await self.connect()
        try:
            price = await self.ticker_price()
            snap = await self.account_snapshot(price)
            return {
                "exchange": self.ex.id,
                "price": price,
                **snap,
            }
        finally:
            await self.close()
