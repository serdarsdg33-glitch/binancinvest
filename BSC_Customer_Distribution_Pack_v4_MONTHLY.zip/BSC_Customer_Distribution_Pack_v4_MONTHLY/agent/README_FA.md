# BSC Bot Agent

این سرویس برای نسخه موبایل است. موتور معامله روی Agent اجرا می‌شود و موبایل فقط کنترل/نمایش را انجام می‌دهد.

- برای استفاده فقط در همان کامپیوتر: Host روی 127.0.0.1 بماند.
- برای کنترل از گوشی در شبکه محلی: می‌توان Host را 0.0.0.0 کرد ولی فایروال و شبکه خصوصی را رعایت کنید.
- برای کنترل از اینترنت: Agent را مستقیم با HTTP روی اینترنت باز نکنید؛ پشت HTTPS reverse proxy/VPN/Tunnel قرار دهید.
- API صرافی فقط Read/Trade و Withdrawal خاموش.

Pairing Token هنگام اولین اجرا ساخته و در پوشه داده BSC ذخیره می‌شود.

## اجرای موبایل در شبکه محلی
Agent فایل‌های Mobile PWA را خودش سرو می‌کند. پس از اجرای Agent، روی گوشی همان شبکه باز کنید:
`http://IP-COMPUTER:8765/mobile/`
سپس Add to Home Screen بزنید. این روش باعث می‌شود Mobile UI و Agent هم‌origin باشند.

برای اینترنت عمومی، Nginx/Caddy/Cloudflare/Tailscale یا روش امن مشابه را به‌صورت HTTPS جلوی Agent قرار دهید. متغیر `BSC_ALLOWED_ORIGINS` را برای دامنه اپ تنظیم کنید.

## Docker/VPS
`docker compose up -d --build`
پورت نمونه compose فقط روی 127.0.0.1 bind شده تا ابتدا reverse proxy HTTPS جلوی آن قرار دهید.


## BSC 30-Day Subscription

BSC Bot uses an online 30-day subscription license.
Your License Key stays the same after renewal; a new payment extends the subscription by 30 days.
The first activation binds the key to the device.
Before LIVE trading, the application checks the subscription with BinancInvest.
If the subscription expires while a position is already open, the bot blocks new entries but continues local risk management for the existing position until it is closed.

Renewal prices:
- BSC Spot Bot: $99 / 30 days
- BSC Futures Bot: $129 / 30 days
- BSC Universal Bot: $179 / 30 days
