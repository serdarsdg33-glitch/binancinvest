@echo off
setlocal
py -m pip install -r requirements.txt pyinstaller
py -m PyInstaller --noconfirm --clean --onedir --name BSC_Bot_Agent --collect-all ccxt --collect-all cryptography --add-data "mobile_www;mobile_www" agent_server.py
if errorlevel 1 goto :fail
echo Built: dist\BSC_Bot_Agent\BSC_Bot_Agent.exe
pause
exit /b 0
:fail
echo BUILD FAILED
pause
exit /b 1
