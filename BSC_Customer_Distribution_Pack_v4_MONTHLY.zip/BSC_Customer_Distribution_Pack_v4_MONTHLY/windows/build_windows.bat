\
@echo off
setlocal
title BSC Universal Trading Bot Builder

echo ==========================================
echo   BSC Universal Trading Bot - Windows Build
echo ==========================================
echo.

where py >nul 2>&1
if errorlevel 1 (
  echo Python launcher "py" was not found.
  echo Install Python 3.11+ and run this file again.
  pause
  exit /b 1
)

py -m pip install --upgrade pip
if errorlevel 1 goto :fail

py -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo Building Windows executable...
py -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --windowed ^
  --name "BSC_Universal_Trading_Bot" ^
  --collect-all ccxt ^
  --collect-all keyring ^
  --collect-all cryptography ^
  app.py
if errorlevel 1 goto :fail

echo.
echo SUCCESS
echo EXE:
echo %CD%\dist\BSC_Universal_Trading_Bot.exe
echo.
pause
exit /b 0

:fail
echo.
echo BUILD FAILED. Read the error above.
pause
exit /b 1
