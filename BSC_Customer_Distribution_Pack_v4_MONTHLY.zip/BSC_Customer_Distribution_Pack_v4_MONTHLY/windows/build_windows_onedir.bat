\
@echo off
setlocal
title BSC Universal Trading Bot - Test Build

py -m pip install -r requirements.txt
if errorlevel 1 goto :fail

py -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onedir ^
  --windowed ^
  --name "BSC_Universal_Trading_Bot" ^
  --collect-all ccxt ^
  --collect-all keyring ^
  app.py
if errorlevel 1 goto :fail

echo Test build created in dist\BSC_Universal_Trading_Bot
pause
exit /b 0

:fail
echo BUILD FAILED
pause
exit /b 1
