\
from __future__ import annotations
import asyncio
import json
import queue
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

from bsc_trader import APP_NAME, APP_VERSION
from bsc_trader.config import default_config, validate_config
from bsc_trader.engine import TradingEngine
from bsc_trader.exchange import UniversalExchange
from bsc_trader.paths import settings_path, state_path
from bsc_trader.vault import save_credentials, load_credentials, delete_credentials
from bsc_trader.license import device_id, current_license, activate_license_key, saved_license_key

BG = "#0a0f18"
PANEL = "#111827"
PANEL_2 = "#182231"
TEXT = "#f5f7fb"
MUTED = "#93a4b8"
GOLD = "#f3ba2f"
GREEN = "#22c55e"
RED = "#ef4444"

COMMON_EXCHANGES = ["bitget", "binance", "bybit", "okx", "kucoin", "gateio", "mexc", "cryptocom"]
TIMEFRAMES = ["1m", "3m", "5m", "15m", "30m", "1h", "4h"]

class BSCApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry("1060x760")
        self.minsize(940, 680)
        self.configure(bg=BG)

        self.log_q = queue.Queue()
        self.status_q = queue.Queue()
        self.bot_thread = None
        self.stop_flag = threading.Event()
        self.connected_ok = False

        self._make_styles()
        self._make_vars()
        self._build_ui()
        self._load_ui_settings()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(150, self._drain_queues)

    def _make_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, padding=(18, 10))
        style.map("TNotebook.Tab", background=[("selected", PANEL_2)], foreground=[("selected", GOLD)])
        style.configure("TCombobox", fieldbackground=PANEL_2, background=PANEL_2, foreground=TEXT)
        style.configure("TCheckbutton", background=PANEL, foreground=TEXT)
        style.map("TCheckbutton", background=[("active", PANEL)])

    def _make_vars(self):
        self.exchange = tk.StringVar(value="bitget")
        self.profile = tk.StringVar(value="main")
        self.api_key = tk.StringVar()
        self.api_secret = tk.StringVar()
        self.api_password = tk.StringVar()

        self.market_type = tk.StringVar(value="spot")
        self.symbol = tk.StringVar(value="BTC/USDT")
        self.timeframe = tk.StringVar(value="15m")
        self.risk = tk.StringVar(value="0.35")
        self.daily_loss = tk.StringVar(value="2.0")
        self.position_cap = tk.StringVar(value="20")
        self.margin_cap = tk.StringVar(value="12")
        self.leverage = tk.StringVar(value="3")
        self.stop_atr = tk.StringVar(value="1.8")
        self.tp_rr = tk.StringVar(value="2.2")
        self.trailing_atr = tk.StringVar(value="1.4")

        self.ema_fast = tk.StringVar(value="20")
        self.ema_slow = tk.StringVar(value="50")
        self.min_adx = tk.StringVar(value="18")
        self.vol_ratio = tk.StringVar(value="0.80")
        self.rsi_long_min = tk.StringVar(value="52")
        self.rsi_long_max = tk.StringVar(value="72")
        self.rsi_short_min = tk.StringVar(value="28")
        self.rsi_short_max = tk.StringVar(value="48")

        self.live_ack = tk.BooleanVar(value=False)

        self.status_state = tk.StringVar(value="STOPPED")
        self.status_exchange = tk.StringVar(value="-")
        self.status_price = tk.StringVar(value="-")
        self.status_equity = tk.StringVar(value="-")
        self.status_pnl = tk.StringVar(value="-")
        self.status_position = tk.StringVar(value="NONE")
        self.status_signal = tk.StringVar(value="-")
        self.status_rsi = tk.StringVar(value="-")
        self.status_adx = tk.StringVar(value="-")
        self.license_status = tk.StringVar(value="UNLICENSED")
        self.device_id_var = tk.StringVar(value=device_id())
        self.license_key_var = tk.StringVar(value=saved_license_key())

    def _build_ui(self):
        header = tk.Frame(self, bg=BG, height=82)
        header.pack(fill="x", padx=24, pady=(18, 0))

        tk.Label(header, text="BSC", font=("Segoe UI", 26, "bold"), fg=GOLD, bg=BG).pack(side="left")
        tk.Label(
            header, text=" UNIVERSAL TRADING BOT", font=("Segoe UI", 17, "bold"),
            fg=TEXT, bg=BG
        ).pack(side="left", pady=(7, 0))

        badge = tk.Label(
            header, text="LIVE", font=("Segoe UI", 10, "bold"),
            fg="#07110a", bg=GREEN, padx=9, pady=4
        )
        badge.pack(side="right", pady=9)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=24, pady=16)

        self.dashboard_tab = tk.Frame(self.notebook, bg=BG)
        self.connection_tab = tk.Frame(self.notebook, bg=BG)
        self.strategy_tab = tk.Frame(self.notebook, bg=BG)
        self.logs_tab = tk.Frame(self.notebook, bg=BG)

        self.notebook.add(self.dashboard_tab, text="Dashboard")
        self.notebook.add(self.connection_tab, text="Connection")
        self.notebook.add(self.strategy_tab, text="Strategy")
        self.notebook.add(self.logs_tab, text="Logs")

        self._build_dashboard()
        self._build_connection()
        self._build_strategy()
        self._build_logs()

    def _card(self, parent, title):
        box = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground="#243246")
        tk.Label(box, text=title, font=("Segoe UI", 11, "bold"), fg=MUTED, bg=PANEL).pack(
            anchor="w", padx=16, pady=(13, 4)
        )
        return box

    def _metric(self, parent, title, var, col):
        box = self._card(parent, title)
        box.grid(row=0, column=col, sticky="nsew", padx=6, pady=6)
        tk.Label(box, textvariable=var, font=("Segoe UI", 18, "bold"), fg=TEXT, bg=PANEL).pack(
            anchor="w", padx=16, pady=(2, 16)
        )

    def _build_dashboard(self):
        top = tk.Frame(self.dashboard_tab, bg=BG)
        top.pack(fill="x")
        for i in range(5):
            top.columnconfigure(i, weight=1)

        self._metric(top, "BOT STATUS", self.status_state, 0)
        self._metric(top, "EQUITY", self.status_equity, 1)
        self._metric(top, "MARKET PRICE", self.status_price, 2)
        self._metric(top, "TODAY PNL", self.status_pnl, 3)
        self._metric(top, "POSITION", self.status_position, 4)

        middle = tk.Frame(self.dashboard_tab, bg=BG)
        middle.pack(fill="x", pady=(10, 0))
        middle.columnconfigure(0, weight=2)
        middle.columnconfigure(1, weight=1)

        control = self._card(middle, "BOT CONTROL")
        control.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)

        row1 = tk.Frame(control, bg=PANEL)
        row1.pack(fill="x", padx=16, pady=8)

        self.start_btn = tk.Button(
            row1, text="START LIVE BOT", command=self.start_bot,
            bg=GOLD, fg="#17130a", activebackground="#d8a82d",
            relief="flat", font=("Segoe UI", 11, "bold"), padx=22, pady=12
        )
        self.start_btn.pack(side="left", padx=(0, 10))

        self.stop_btn = tk.Button(
            row1, text="STOP", command=self.stop_bot, state="disabled",
            bg="#2b3545", fg=TEXT, activebackground="#39465a",
            relief="flat", font=("Segoe UI", 11, "bold"), padx=22, pady=12
        )
        self.stop_btn.pack(side="left")

        tk.Checkbutton(
            control,
            text="I understand this sends REAL orders and can lose money.",
            variable=self.live_ack,
            bg=PANEL, fg=MUTED, selectcolor=PANEL_2, activebackground=PANEL,
            activeforeground=TEXT, font=("Segoe UI", 10)
        ).pack(anchor="w", padx=16, pady=(4, 14))

        signal = self._card(middle, "SIGNAL ENGINE")
        signal.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)
        for label, var in [
            ("Signal", self.status_signal),
            ("RSI", self.status_rsi),
            ("ADX", self.status_adx),
        ]:
            r = tk.Frame(signal, bg=PANEL)
            r.pack(fill="x", padx=16, pady=5)
            tk.Label(r, text=label, fg=MUTED, bg=PANEL).pack(side="left")
            tk.Label(r, textvariable=var, fg=TEXT, bg=PANEL, font=("Segoe UI", 10, "bold")).pack(side="right")

        info = self._card(self.dashboard_tab, "CURRENT CONFIGURATION")
        info.pack(fill="x", padx=6, pady=10)
        self.config_summary = tk.Label(
            info, text="", justify="left", fg=TEXT, bg=PANEL,
            font=("Consolas", 10), padx=16, pady=12
        )
        self.config_summary.pack(fill="x")
        self._refresh_summary()

        lic = self._card(self.dashboard_tab, "LICENSE")
        lic.pack(fill="x", padx=6, pady=10)
        lr = tk.Frame(lic, bg=PANEL)
        lr.pack(fill="x", padx=16, pady=(6, 12))
        tk.Label(lr, text="Status:", fg=MUTED, bg=PANEL).pack(side="left")
        tk.Label(lr, textvariable=self.license_status, fg=GOLD, bg=PANEL, font=("Segoe UI", 10, "bold")).pack(side="left", padx=(6, 16))
        tk.Label(lr, text="License Key:", fg=MUTED, bg=PANEL).pack(side="left")
        tk.Entry(lr, textvariable=self.license_key_var, width=36, bg=PANEL_2, fg=TEXT, insertbackground=TEXT, relief="flat").pack(side="left", padx=6, ipady=5)
        tk.Button(lr, text="ACTIVATE", command=self.activate_license, bg="#263245", fg=TEXT, relief="flat", padx=12, pady=7).pack(side="right")
        self._refresh_license()

    def _field(self, parent, label, var, row, col=0, width=26, show=None):
        tk.Label(parent, text=label, fg=MUTED, bg=PANEL, font=("Segoe UI", 9)).grid(
            row=row, column=col, sticky="w", padx=14, pady=(8, 2)
        )
        e = tk.Entry(
            parent, textvariable=var, width=width, show=show,
            bg=PANEL_2, fg=TEXT, insertbackground=TEXT, relief="flat",
            font=("Segoe UI", 10)
        )
        e.grid(row=row+1, column=col, sticky="ew", padx=14, pady=(0, 7), ipady=7)
        return e

    def _build_connection(self):
        outer = self._card(self.connection_tab, "EXCHANGE CONNECTION")
        outer.pack(fill="x", padx=6, pady=6)
        outer.columnconfigure(0, weight=1)
        outer.columnconfigure(1, weight=1)

        tk.Label(outer, text="Exchange ID", fg=MUTED, bg=PANEL).grid(row=0, column=0, sticky="w", padx=14, pady=(10, 2))
        combo = ttk.Combobox(outer, textvariable=self.exchange, values=COMMON_EXCHANGES)
        combo.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 7), ipady=5)

        self._field(outer, "Profile name", self.profile, 0, 1)
        self._field(outer, "API Key", self.api_key, 2, 0)
        self._field(outer, "API Secret", self.api_secret, 2, 1, show="•")
        self._field(outer, "API Passphrase / Password (if required)", self.api_password, 4, 0, show="•")

        btns = tk.Frame(outer, bg=PANEL)
        btns.grid(row=5, column=1, rowspan=2, sticky="e", padx=14, pady=16)

        tk.Button(
            btns, text="SAVE SECURELY", command=self.save_api,
            bg=GOLD, fg="#17130a", relief="flat", padx=13, pady=9,
            font=("Segoe UI", 9, "bold")
        ).pack(side="left", padx=4)
        tk.Button(
            btns, text="TEST CONNECTION", command=self.test_connection,
            bg="#263245", fg=TEXT, relief="flat", padx=13, pady=9
        ).pack(side="left", padx=4)
        tk.Button(
            btns, text="DELETE SAVED", command=self.delete_api,
            bg="#35232a", fg="#fecaca", relief="flat", padx=13, pady=9
        ).pack(side="left", padx=4)

        note = self._card(self.connection_tab, "SECURITY")
        note.pack(fill="x", padx=6, pady=10)
        tk.Label(
            note,
            text=(
                "API credentials are stored through the operating system credential vault, not inside the bot source/config.\n"
                "Create trading-only API keys. Do NOT enable withdrawal permission."
            ),
            fg=MUTED, bg=PANEL, justify="left", font=("Segoe UI", 10)
        ).pack(anchor="w", padx=16, pady=(6, 16))

    def _build_strategy(self):
        main = tk.Frame(self.strategy_tab, bg=BG)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.columnconfigure(1, weight=1)

        trade = self._card(main, "TRADE & RISK")
        trade.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        trade.columnconfigure(0, weight=1)
        trade.columnconfigure(1, weight=1)

        tk.Label(trade, text="Market", fg=MUTED, bg=PANEL).grid(row=0, column=0, sticky="w", padx=14, pady=(8,2))
        market_combo = ttk.Combobox(trade, textvariable=self.market_type, values=["spot", "swap"], state="readonly")
        market_combo.grid(row=1, column=0, sticky="ew", padx=14, pady=(0,7), ipady=5)
        market_combo.bind("<<ComboboxSelected>>", self._on_market_change)

        self._field(trade, "Symbol", self.symbol, 0, 1)
        tk.Label(trade, text="Timeframe", fg=MUTED, bg=PANEL).grid(row=2, column=0, sticky="w", padx=14, pady=(8,2))
        tf = ttk.Combobox(trade, textvariable=self.timeframe, values=TIMEFRAMES)
        tf.grid(row=3, column=0, sticky="ew", padx=14, pady=(0,7), ipady=5)
        self._field(trade, "Risk / trade %", self.risk, 2, 1)
        self._field(trade, "Max daily loss %", self.daily_loss, 4, 0)
        self._field(trade, "Spot max position %", self.position_cap, 4, 1)
        self._field(trade, "Futures max margin %", self.margin_cap, 6, 0)
        self._field(trade, "Leverage", self.leverage, 6, 1)
        self._field(trade, "Stop ATR", self.stop_atr, 8, 0)
        self._field(trade, "Take Profit R:R", self.tp_rr, 8, 1)
        self._field(trade, "Trailing ATR", self.trailing_atr, 10, 0)

        strat = self._card(main, "STRATEGY FILTERS")
        strat.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)
        strat.columnconfigure(0, weight=1)
        strat.columnconfigure(1, weight=1)

        self._field(strat, "EMA Fast", self.ema_fast, 0, 0)
        self._field(strat, "EMA Slow", self.ema_slow, 0, 1)
        self._field(strat, "Minimum ADX", self.min_adx, 2, 0)
        self._field(strat, "Minimum volume ratio", self.vol_ratio, 2, 1)
        self._field(strat, "Long RSI min", self.rsi_long_min, 4, 0)
        self._field(strat, "Long RSI max", self.rsi_long_max, 4, 1)
        self._field(strat, "Short RSI min", self.rsi_short_min, 6, 0)
        self._field(strat, "Short RSI max", self.rsi_short_max, 6, 1)

        tk.Button(
            strat, text="APPLY SETTINGS", command=self.apply_settings,
            bg=GOLD, fg="#17130a", relief="flat", padx=18, pady=10,
            font=("Segoe UI", 10, "bold")
        ).grid(row=8, column=0, columnspan=2, sticky="e", padx=14, pady=18)

    def _build_logs(self):
        box = self._card(self.logs_tab, "LIVE LOG")
        box.pack(fill="both", expand=True, padx=6, pady=6)
        self.log_text = tk.Text(
            box, bg="#070b12", fg="#cbd5e1", insertbackground=TEXT,
            relief="flat", font=("Consolas", 10), wrap="word"
        )
        self.log_text.pack(fill="both", expand=True, padx=12, pady=(5, 12))
        self._log("BSC Universal Trading Bot ready.")

    def _on_market_change(self, _evt=None):
        if self.market_type.get() == "spot":
            if ":USDT" in self.symbol.get():
                self.symbol.set(self.symbol.get().split(":")[0])
        else:
            if ":" not in self.symbol.get() and self.symbol.get().endswith("/USDT"):
                self.symbol.set(self.symbol.get() + ":USDT")
        self._refresh_summary()

    def _config_from_ui(self):
        cfg = default_config()
        cfg.update({
            "market_type": self.market_type.get().strip(),
            "symbol": self.symbol.get().strip(),
            "timeframe": self.timeframe.get().strip(),
            "risk_per_trade_pct": float(self.risk.get()),
            "max_daily_loss_pct": float(self.daily_loss.get()),
            "max_position_pct": float(self.position_cap.get()),
            "max_margin_pct": float(self.margin_cap.get()),
            "leverage": int(float(self.leverage.get())),
            "stop_atr": float(self.stop_atr.get()),
            "take_profit_rr": float(self.tp_rr.get()),
            "trailing_atr": float(self.trailing_atr.get()),
        })
        cfg["strategy"].update({
            "ema_fast": int(float(self.ema_fast.get())),
            "ema_slow": int(float(self.ema_slow.get())),
            "min_adx": float(self.min_adx.get()),
            "min_volume_ratio": float(self.vol_ratio.get()),
            "rsi_long_min": float(self.rsi_long_min.get()),
            "rsi_long_max": float(self.rsi_long_max.get()),
            "rsi_short_min": float(self.rsi_short_min.get()),
            "rsi_short_max": float(self.rsi_short_max.get()),
        })
        validate_config(cfg)
        return cfg

    def _refresh_license(self):
        try:
            lic = current_license(self.market_type.get(), allow_cache=True)
            exp = str(lic.get("expires_at", ""))
            self.license_status.set(f"ACTIVE · {lic.get('product_code','BSC')} · exp {exp[:10]}")
        except Exception as e:
            self.license_status.set("RENEW / ACTIVATE")

    def activate_license(self):
        try:
            info = activate_license_key(self.license_key_var.get())
            self.license_key_var.set(saved_license_key())
            self._refresh_license()
            messagebox.showinfo(
                "BSC",
                f"Subscription activated: {info.get('product_code','BSC')}\nExpires: {info.get('expires_at','')}"
            )
        except Exception as e:
            messagebox.showerror("License", str(e))

    def save_api(self):
        try:
            save_credentials(
                self.exchange.get(), self.profile.get(),
                self.api_key.get(), self.api_secret.get(), self.api_password.get()
            )
            self.api_secret.set("")
            self.api_password.set("")
            self.connected_ok = False
            self._log("API credentials saved securely.")
            messagebox.showinfo("BSC", "API credentials were saved securely.")
        except Exception as e:
            messagebox.showerror("Save failed", str(e))

    def delete_api(self):
        if delete_credentials(self.exchange.get(), self.profile.get()):
            self._log("Saved API credentials deleted.")
            messagebox.showinfo("BSC", "Saved API credentials deleted.")
        else:
            messagebox.showinfo("BSC", "No saved credentials were found.")

    def test_connection(self):
        try:
            cfg = self._config_from_ui()
            creds = load_credentials(self.exchange.get(), self.profile.get())
        except Exception as e:
            messagebox.showerror("Connection", str(e))
            return

        self._log("Testing exchange connection...")
        def worker():
            ux = UniversalExchange(self.exchange.get(), creds, cfg)
            try:
                result = asyncio.run(ux.test_connection())
                self.status_q.put({
                    "connection_test": True,
                    "ok": True,
                    "result": result,
                })
            except Exception as e:
                self.status_q.put({
                    "connection_test": True,
                    "ok": False,
                    "error": str(e),
                })
        threading.Thread(target=worker, daemon=True).start()

    def apply_settings(self):
        try:
            self._config_from_ui()
            self._save_ui_settings()
            self._refresh_summary()
            self.connected_ok = False
            self._log("Settings applied. Re-test connection before starting.")
            messagebox.showinfo("BSC", "Settings applied.")
        except Exception as e:
            messagebox.showerror("Settings", str(e))

    def start_bot(self):
        if self.bot_thread and self.bot_thread.is_alive():
            return
        try:
            current_license(self.market_type.get(), allow_cache=True)
        except Exception as e:
            messagebox.showerror("BSC Subscription", f"{e}\n\nRenew or activate your subscription at BinancInvest.")
            return
        if not self.live_ack.get():
            messagebox.showwarning(
                "LIVE trading",
                "Tick the LIVE trading confirmation before starting."
            )
            return
        if not self.connected_ok:
            messagebox.showwarning(
                "Connection test required",
                "Test the connection successfully after your latest settings before starting."
            )
            self.notebook.select(self.connection_tab)
            return
        try:
            cfg = self._config_from_ui()
            creds = load_credentials(self.exchange.get(), self.profile.get())
        except Exception as e:
            messagebox.showerror("Start failed", str(e))
            return

        self.stop_flag.clear()
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status_state.set("STARTING")
        self._save_ui_settings()

        exchange_id = self.exchange.get().strip().lower()
        profile = self.profile.get().strip() or "main"
        st_path = state_path(exchange_id, profile, cfg["market_type"], cfg["symbol"])

        def log_cb(msg):
            self.log_q.put(msg)

        def status_cb(data):
            self.status_q.put(data)

        def worker():
            engine = TradingEngine(
                exchange_id, creds, cfg, st_path,
                log=log_cb, status=status_cb
            )
            try:
                asyncio.run(engine.run(self.stop_flag))
            except Exception as e:
                self.log_q.put(f"FATAL: {type(e).__name__}: {e}")
                self.status_q.put({"state": "ERROR", "message": str(e)})
            finally:
                self.status_q.put({"bot_finished": True})

        self.bot_thread = threading.Thread(target=worker, daemon=True)
        self.bot_thread.start()
        self._log("Starting LIVE trading engine...")

    def stop_bot(self):
        if self.bot_thread and self.bot_thread.is_alive():
            self.stop_flag.set()
            self.status_state.set("STOPPING")
            self._log("Stop requested. No new entries will be opened.")
            self.stop_btn.configure(state="disabled")

    def _drain_queues(self):
        try:
            while True:
                self._log(self.log_q.get_nowait())
        except queue.Empty:
            pass

        try:
            while True:
                data = self.status_q.get_nowait()
                self._apply_status(data)
        except queue.Empty:
            pass

        self.after(150, self._drain_queues)

    def _apply_status(self, data):
        if data.get("connection_test"):
            if data.get("ok"):
                r = data["result"]
                self.connected_ok = True
                self.status_exchange.set(r["exchange"].upper())
                self.status_equity.set(f"{r['equity']:.2f} {r['quote']}")
                self.status_price.set(f"{r['price']:.8g}")
                self._log(
                    f"Connection OK: {r['exchange'].upper()} | "
                    f"equity≈{r['equity']:.2f} {r['quote']}"
                )
                messagebox.showinfo("BSC", "Connection successful.")
            else:
                self.connected_ok = False
                self._log(f"Connection failed: {data.get('error')}")
                messagebox.showerror("Connection failed", data.get("error", "Unknown error"))
            return

        if data.get("bot_finished"):
            self.start_btn.configure(state="normal")
            self.stop_btn.configure(state="disabled")
            if self.status_state.get() != "ERROR":
                self.status_state.set("STOPPED")
            return

        if "state" in data:
            self.status_state.set(str(data["state"]))
        if "price" in data:
            self.status_price.set(f"{float(data['price']):.8g}")
        if "equity" in data:
            quote = data.get("quote", "")
            self.status_equity.set(f"{float(data['equity']):.2f} {quote}".strip())
        if "daily_pnl" in data:
            quote = data.get("quote", "")
            self.status_pnl.set(f"{float(data['daily_pnl']):+.2f} {quote}".strip())
        if "position" in data:
            self.status_position.set(str(data["position"]))
        if "signal" in data:
            self.status_signal.set(str(data["signal"]))
        if "rsi" in data:
            self.status_rsi.set(str(data["rsi"]))
        if "adx" in data:
            self.status_adx.set(str(data["adx"]))
        if data.get("message"):
            self._log(data["message"])

    def _log(self, msg):
        if not hasattr(self, "log_text"):
            return
        from datetime import datetime
        stamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{stamp}] {msg}\n")
        self.log_text.see("end")

    def _refresh_summary(self):
        if not hasattr(self, "config_summary"):
            return
        self.config_summary.configure(text=(
            f"Exchange: {self.exchange.get().upper()}    "
            f"Mode: {self.market_type.get().upper()}    "
            f"Symbol: {self.symbol.get()}    "
            f"TF: {self.timeframe.get()}\n"
            f"Risk/trade: {self.risk.get()}%    "
            f"Daily loss limit: {self.daily_loss.get()}%    "
            f"Leverage: {self.leverage.get()}x    "
            f"SL: {self.stop_atr.get()} ATR    "
            f"TP: {self.tp_rr.get()}R"
        ))

    def _save_ui_settings(self):
        data = {
            "exchange": self.exchange.get(),
            "profile": self.profile.get(),
            "market_type": self.market_type.get(),
            "symbol": self.symbol.get(),
            "timeframe": self.timeframe.get(),
            "risk": self.risk.get(),
            "daily_loss": self.daily_loss.get(),
            "position_cap": self.position_cap.get(),
            "margin_cap": self.margin_cap.get(),
            "leverage": self.leverage.get(),
            "stop_atr": self.stop_atr.get(),
            "tp_rr": self.tp_rr.get(),
            "trailing_atr": self.trailing_atr.get(),
            "ema_fast": self.ema_fast.get(),
            "ema_slow": self.ema_slow.get(),
            "min_adx": self.min_adx.get(),
            "vol_ratio": self.vol_ratio.get(),
            "rsi_long_min": self.rsi_long_min.get(),
            "rsi_long_max": self.rsi_long_max.get(),
            "rsi_short_min": self.rsi_short_min.get(),
            "rsi_short_max": self.rsi_short_max.get(),
        }
        settings_path().write_text(json.dumps(data, indent=2), encoding="utf-8")

    def _load_ui_settings(self):
        p = settings_path()
        if not p.exists():
            self._refresh_summary()
            return
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            mapping = {
                "exchange": self.exchange, "profile": self.profile,
                "market_type": self.market_type, "symbol": self.symbol,
                "timeframe": self.timeframe, "risk": self.risk,
                "daily_loss": self.daily_loss, "position_cap": self.position_cap,
                "margin_cap": self.margin_cap, "leverage": self.leverage,
                "stop_atr": self.stop_atr, "tp_rr": self.tp_rr,
                "trailing_atr": self.trailing_atr, "ema_fast": self.ema_fast,
                "ema_slow": self.ema_slow, "min_adx": self.min_adx,
                "vol_ratio": self.vol_ratio, "rsi_long_min": self.rsi_long_min,
                "rsi_long_max": self.rsi_long_max, "rsi_short_min": self.rsi_short_min,
                "rsi_short_max": self.rsi_short_max,
            }
            for k, var in mapping.items():
                if k in data:
                    var.set(data[k])
        except Exception:
            pass
        self._refresh_summary()

    def _on_close(self):
        if self.bot_thread and self.bot_thread.is_alive():
            if not messagebox.askyesno(
                "BSC",
                "The LIVE bot is running. Closing the app stops local monitoring.\n\n"
                "Do you still want to close?"
            ):
                return
            self.stop_flag.set()
        self.destroy()

if __name__ == "__main__":
    app = BSCApp()
    app.mainloop()
