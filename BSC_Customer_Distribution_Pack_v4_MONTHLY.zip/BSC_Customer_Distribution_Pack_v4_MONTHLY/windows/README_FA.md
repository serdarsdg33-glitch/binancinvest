# BSC Universal Trading Bot v2

نسخه دسکتاپ LIVE برای Windows.

## داخل برنامه چه داریم؟

- یک برنامه واحد برای Spot و Futures
- انتخاب صرافی با CCXT Exchange ID
- Bitget / Binance / Bybit / OKX / KuCoin / Gate.io / MEXC و صرافی‌های سازگار دیگر
- API Key + Secret + Passphrase
- ذخیره API از طریق Credential Vault سیستم‌عامل
- Test Connection قبل از شروع
- انتخاب Symbol و Timeframe
- Risk per Trade
- Max Daily Loss
- Position/Margin Cap
- Leverage
- ATR Stop Loss
- Take Profit با Risk/Reward
- Trailing Stop
- EMA / RSI / ADX / Volume filters
- جلوگیری از تکرار سیگنال روی یک کندل
- توقف موقت بعد از چند ضرر متوالی
- بررسی پوزیشن Futures با صرافی قبل از خروج
- Dashboard و Live Log

## نکته بسیار مهم درباره LIVE

این ربات سفارش واقعی می‌فرستد و سود تضمینی ندارد.

API مشتری باید فقط مجوز Read/Trade داشته باشد و **Withdraw باید خاموش باشد**.

### محافظت SL/TP در نسخه 2

برای سازگاری چندصرافی، Stop/TP این نسخه داخل خود برنامه مانیتور می‌شود و هنگام رسیدن قیمت، Market Exit می‌فرستد. بنابراین برنامه باید باز و اینترنت آن پایدار باشد.

در نسخه بعد، برای صرافی‌های اصلی آداپتر اختصاصی Native Exchange Stop/TP اضافه می‌شود تا سفارش محافظتی روی خود صرافی قرار بگیرد.

## ساخت EXE در Windows

### روش ساده

1. Python 3.11+ را روی Windows نصب کنید.
2. کل پوشه پروژه را Extract کنید.
3. روی `build_windows_onedir.bat` بزنید و اول نسخه تست را بسازید.
4. اگر درست بود روی `build_windows.bat` بزنید.
5. خروجی نهایی:

`dist\BSC_Universal_Trading_Bot.exe`

PyInstaller داخل EXE، Python و dependencyهای لازم را Bundle می‌کند؛ بنابراین مشتری نهایی برای اجرای EXE نیازی به نصب Python ندارد.

## ساخت اتوماتیک در GitHub

فایل زیر داخل پروژه قرار دارد:

`.github/workflows/build-windows.yml`

اگر پروژه را روی GitHub قرار دهید، GitHub Actions می‌تواند Build ویندوز را اجرا کند و EXE را به‌عنوان Artifact تحویل دهد.

## اتصال مشتری

هر مشتری:

1. در صرافی خودش API مخصوص خودش می‌سازد.
2. Withdrawal را خاموش نگه می‌دارد.
3. BSC Bot را باز می‌کند.
4. Exchange ID و API را وارد می‌کند.
5. Save Securely را می‌زند.
6. Test Connection را می‌زند.
7. Strategy/Risk را تنظیم می‌کند.
8. تیک LIVE را فعال می‌کند.
9. Start Live Bot را می‌زند.

اطلاعات API مشتری برای استفاده عادی نیازی ندارد به سایت BSC ارسال شود.

## مثال Symbol

Spot:
`BTC/USDT`

Futures/Swap در خیلی از صرافی‌ها:
`BTC/USDT:USDT`

نماد دقیق باید در بازار همان صرافی وجود داشته باشد.

## برند

نام محصول در این نسخه:

**BSC Universal Trading Bot**


## BSC 30-Day Subscription

BSC Bot uses an online 30-day subscription license.
Your License Key stays the same after renewal; a new payment extends the subscription by 30 days.
The first activation binds the key to the device.
Before LIVE trading, the application checks the subscription with BinancInvest.
If the subscription expires while a position is already open, the bot blocks new entries but continues local risk management for the existing position until it is closed.

Renewal prices:
- BSC Spot Bot: $99 / 30 days
- BSC Futures Bot: $129 / 30 days
- BSC Universal Bot: $179 / 30 days
