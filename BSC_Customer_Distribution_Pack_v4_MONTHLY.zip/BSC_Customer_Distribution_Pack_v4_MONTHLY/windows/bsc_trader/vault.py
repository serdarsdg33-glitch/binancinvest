\
from __future__ import annotations
import json
import keyring

SERVICE = "BSC Universal Trading Bot"

def _username(exchange_id: str, profile: str) -> str:
    return f"{exchange_id.strip().lower()}::{profile.strip() or 'main'}"

def save_credentials(exchange_id: str, profile: str, api_key: str, api_secret: str, api_password: str = "") -> None:
    if not api_key.strip() or not api_secret.strip():
        raise ValueError("API Key and API Secret are required.")
    payload = json.dumps({
        "api_key": api_key.strip(),
        "api_secret": api_secret.strip(),
        "api_password": api_password.strip(),
    })
    keyring.set_password(SERVICE, _username(exchange_id, profile), payload)

def load_credentials(exchange_id: str, profile: str) -> dict:
    raw = keyring.get_password(SERVICE, _username(exchange_id, profile))
    if not raw:
        raise RuntimeError("No saved API credentials found for this exchange/profile.")
    data = json.loads(raw)
    if not data.get("api_key") or not data.get("api_secret"):
        raise RuntimeError("Saved credentials are incomplete.")
    return data

def delete_credentials(exchange_id: str, profile: str) -> bool:
    user = _username(exchange_id, profile)
    try:
        keyring.delete_password(SERVICE, user)
        return True
    except keyring.errors.PasswordDeleteError:
        return False
