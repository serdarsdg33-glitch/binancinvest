# BSC Mobile

این نسخه رابط موبایل است. موتور ترید 24/7 روی BSC Bot Agent اجرا می‌شود. این معماری برای iPhone قابل‌اعتمادتر است چون iOS معمولاً اپ‌های عادی را در پس‌زمینه suspend می‌کند.

## روش سریع PWA
پوشه `www` را روی HTTPS هاست کنید. در Safari/Chrome باز کنید و Add to Home Screen بزنید.

## Android/iOS Native با Capacitor
`npm install` سپس `npx cap add android` یا `npx cap add ios` و `npx cap sync`. برای Android از Android Studio و برای iOS از Xcode و Apple Developer signing استفاده کنید.

اپ موبایل API Secret را نگه نمی‌دارد؛ Secret روی Agent ذخیره می‌شود. برای ارسال Secret از موبایل، Agent URL باید HTTPS باشد.

## بدون هاست جدا برای موبایل
اگر گوشی و Agent در یک شبکه هستند، کافی است `http://IP-AGENT:8765/mobile/` را باز کنید و Add to Home Screen بزنید.


## BSC 30-Day Subscription

BSC Bot uses an online 30-day subscription license.
Your License Key stays the same after renewal; a new payment extends the subscription by 30 days.
The first activation binds the key to the device.
Before LIVE trading, the application checks the subscription with BinancInvest.
If the subscription expires while a position is already open, the bot blocks new entries but continues local risk management for the existing position until it is closed.

Renewal prices:
- BSC Spot Bot: $99 / 30 days
- BSC Futures Bot: $129 / 30 days
- BSC Universal Bot: $179 / 30 days
