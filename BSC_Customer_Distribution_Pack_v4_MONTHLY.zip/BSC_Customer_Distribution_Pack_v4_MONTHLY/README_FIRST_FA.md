# BSC Customer Distribution Pack

این پوشه امن برای توزیع به مشتری است و **کلید خصوصی صدور لایسنس داخل آن نیست**.

- `windows/` برنامه دسکتاپ و Build ویندوز
- `agent/` موتور 24/7 برای Mobile/VPS
- `mobile/` PWA + سورس Capacitor Android/iOS
- `guides/` راهنمای 10 زبان
- `website/` قطعات HTML برای صفحه فروش/تحویل
- `legal_templates/` الگوهای ریسک، حریم خصوصی و شرایط استفاده

قبل از فروش عمومی، یک Build نهایی Windows روی Windows و یک Build Android/iOS با امضای رسمی ایجاد و روی حساب‌های تست واقعی با مبلغ کم QA کنید.


## BSC 30-Day Subscription

BSC Bot uses an online 30-day subscription license.
Your License Key stays the same after renewal; a new payment extends the subscription by 30 days.
The first activation binds the key to the device.
Before LIVE trading, the application checks the subscription with BinancInvest.
If the subscription expires while a position is already open, the bot blocks new entries but continues local risk management for the existing position until it is closed.

Renewal prices:
- BSC Spot Bot: $99 / 30 days
- BSC Futures Bot: $129 / 30 days
- BSC Universal Bot: $179 / 30 days
