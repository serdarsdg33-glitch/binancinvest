# BSC Trading Bot — Abonnement de 30 jours

Après paiement, ouvrez **Trading Bot → Mes Bots** pour voir l’état, l’expiration, le téléchargement et la License Key. La clé reste identique après renouvellement.

Sous Windows, lancez BSC, collez la License Key et cliquez **ACTIVATE**. La première activation lie la licence à l’appareil. Enregistrez ensuite Exchange ID et API, faites TEST CONNECTION, configurez Spot/Futures et le risque puis démarrez LIVE.

Pour mobile, BSC Bot Agent doit rester actif sur Windows/VPS. Mobile Controller utilise Agent URL et Pairing Token; pour Internet utilisez HTTPS/VPN/tunnel sécurisé.

Abonnement 30 jours: Spot $99, Futures $129, Universal $179. Un renouvellement anticipé ajoute 30 jours après l’expiration actuelle. À expiration, les nouvelles entrées sont bloquées; une position déjà ouverte conserve la gestion de risque existante.

API: Read + Trade uniquement, Withdraw désactivé. Aucun profit n’est garanti.
