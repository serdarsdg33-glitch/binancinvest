# BSC Trading Bot — Suscripción de 30 días

Después del pago ve a **Trading Bot → Mis Bots** para ver estado, vencimiento, descarga y License Key. La clave no cambia al renovar.

En Windows abre BSC, pega la License Key y pulsa **ACTIVATE**. La primera activación vincula la licencia al dispositivo. Guarda Exchange ID y API con SAVE SECURELY, ejecuta TEST CONNECTION, configura Spot/Futures y riesgo y después inicia LIVE.

Para móvil, BSC Bot Agent debe seguir funcionando en Windows/VPS. Mobile Controller usa Agent URL y Pairing Token; para acceso remoto usa HTTPS/VPN/túnel seguro.

Suscripción: Spot $99, Futures $129, Universal $179 por 30 días. Renovar antes añade 30 días después del vencimiento actual. Al expirar se bloquean nuevas entradas; una posición ya abierta continúa bajo la gestión de riesgo existente.

API: solo Read + Trade y Withdraw desactivado. No hay beneficio garantizado.
