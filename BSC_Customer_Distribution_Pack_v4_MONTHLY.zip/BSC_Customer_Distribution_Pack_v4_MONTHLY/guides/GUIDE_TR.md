# BSC Trading Bot — 30 Günlük Abonelik Rehberi

Ödeme sonrası **Trading Bot → Botlarım** bölümünde abonelik durumu, bitiş tarihi, indirme ve License Key görünür. Anahtar yenilemede değişmez.

Windows'ta BSC'yi açın, License Key'i yapıştırıp **ACTIVATE** basın. İlk aktivasyon lisansı cihaza bağlar. Ardından Exchange ID ve API bilgilerini SAVE SECURELY ile kaydedin, TEST CONNECTION yapın, Spot/Futures ve risk ayarlarını belirleyip LIVE botu başlatın.

Mobil kullanımda BSC Bot Agent Windows/VPS üzerinde çalışır; Mobile Controller Agent URL ve Pairing Token ile bağlanır. Uzak erişimde HTTPS/VPN/güvenli tünel kullanın.

Abonelik 30 gündür: Spot $99, Futures $129, Universal $179. Erken yenileme mevcut bitiş tarihinden sonra 30 gün ekler. Süre dolduğunda yeni işlemler engellenir; açık pozisyon varsa mevcut risk yönetimi terk edilmez.

API'de yalnızca Read + Trade açık, Withdraw kapalı olmalıdır. Kâr garantisi yoktur.
