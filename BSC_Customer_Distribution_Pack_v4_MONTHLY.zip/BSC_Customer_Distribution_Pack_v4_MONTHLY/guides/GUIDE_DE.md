# BSC Trading Bot — 30-Tage-Abonnement

Nach erfolgreicher Zahlung öffnen Sie **Trading Bot → Meine Bots**. Dort sehen Sie Status, Ablaufdatum, Download und License Key. Der Schlüssel bleibt bei Verlängerungen gleich.

Unter Windows BSC starten, License Key einfügen und **ACTIVATE** drücken. Die erste Aktivierung bindet die Lizenz an das Gerät. Danach Exchange ID und API sicher speichern, TEST CONNECTION ausführen, Spot/Futures und Risiko konfigurieren und LIVE starten.

Für Mobilsteuerung muss BSC Bot Agent auf Windows/VPS laufen. Mobile Controller verbindet sich mit Agent URL und Pairing Token; für Fernzugriff HTTPS/VPN/sicheren Tunnel verwenden.

30 Tage: Spot $99, Futures $129, Universal $179. Frühe Verlängerung fügt 30 Tage nach dem aktuellen Ablaufdatum hinzu. Nach Ablauf werden neue Entries blockiert; eine bereits offene Position bleibt unter der bestehenden Risikoverwaltung.

API nur Read + Trade; Withdraw deaktiviert. Gewinn ist nicht garantiert.
