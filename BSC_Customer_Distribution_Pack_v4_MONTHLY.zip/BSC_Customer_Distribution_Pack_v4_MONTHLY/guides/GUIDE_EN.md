# BSC Trading Bot — 30-Day Subscription Guide

## 1) After payment
After a successful payment on BinancInvest, open **Trading Bot → My Bots**. You will see the subscription status, expiry date, download button and your **License Key**. The key stays the same after renewals.

## 2) Windows setup
1. Download and extract BSC.
2. Run the Windows application.
3. Copy the License Key from My Bots, paste it into BSC and press **ACTIVATE**.
4. First activation binds the license to that device.
5. Enter Exchange ID and API Key / Secret / Passphrase and press **SAVE SECURELY**.
6. Run **TEST CONNECTION**.
7. Configure Spot/Futures, Symbol, Timeframe and risk.
8. Confirm LIVE and press **START LIVE BOT**.

## 3) Mobile
For mobile control, BSC Bot Agent must keep running on Windows or a VPS. Enter Agent URL and Pairing Token in Mobile Controller. For remote Internet access use HTTPS/VPN/a secure tunnel. Exchange API credentials remain on the Agent.

## 4) Renewal
Subscriptions last 30 days: Spot $99, Futures $129, Universal $179. Renewing early adds 30 days after the existing expiry date. Your License Key does not change.

## 5) Expiration behavior
BSC checks the subscription before LIVE trading and periodically while running. An expired subscription blocks new entries. If a position is already open when access expires, the bot keeps managing that existing position rather than abandoning its local risk protection.

## 6) Security
Use exchange API permissions Read + Trade only; keep Withdraw disabled. Never send your API Secret to the seller. Real trading involves risk and profit is not guaranteed.
