# BSC Trading Bot — 30 günlük abunə təlimatı

## 1) Ödənişdən sonra
BinancInvest-də ödəniş uğurlu olduqdan sonra **Trading Bot → Botlarım** bölməsinə keçin. Abunə statusu, bitmə tarixi, yükləmə düyməsi və **License Key** görünəcək. Yeniləmədə açar dəyişmir.

## 2) Windows
BSC-ni yükləyib açın. Botlarım bölməsindən License Key-ni kopyalayıb proqramda **ACTIVATE** basın. İlk aktivləşmə lisenziyanı həmin cihazın Device ID-sinə bağlayır. Sonra Exchange ID və API məlumatlarını daxil edin, SAVE SECURELY və TEST CONNECTION edin, Spot/Futures, Symbol, Timeframe və risk parametrlərini seçib LIVE rejimini başladın.

## 3) Mobil
Mobil idarəetmə üçün BSC Bot Agent Windows/VPS-də işləməlidir. Mobile Controller-də Agent URL və Pairing Token daxil edin. Uzaq bağlantıda HTTPS/VPN/təhlükəsiz tunel istifadə edin.

## 4) Yeniləmə
Spot $99, Futures $129, Universal $179 — hər biri 30 gündür. Erkən yeniləmə mövcud bitmə tarixindən sonra əlavə 30 gün verir. License Key dəyişmir.

## 5) Abunə bitəndə
Yeni əməliyyat açmaq bloklanır. Açıq mövqe varsa, mövcud risk idarəetməsi mövqeni nəzarətsiz qoymur.

## 6) Təhlükəsizlik
API-də yalnız Read + Trade aktiv olsun, Withdraw bağlı qalsın. API Secret-i satıcıya göndərməyin. Qazanc zəmanətli deyil.
