# BSC Trading Bot — 30天订阅指南

付款成功后进入 **Trading Bot → 我的机器人**，可查看订阅状态、到期时间、下载和 License Key。续费后密钥不会改变。

Windows：运行 BSC，粘贴 License Key 并点击 **ACTIVATE**。首次激活会绑定该设备。然后填写 Exchange ID 与 API 信息，SAVE SECURELY，TEST CONNECTION，设置 Spot/Futures、交易对、周期和风险，再启动 LIVE。

手机控制需要 BSC Bot Agent 持续运行在 Windows/VPS。Mobile Controller 使用 Agent URL 和 Pairing Token 连接；远程访问必须使用 HTTPS/VPN/安全隧道。

订阅为30天：Spot $99、Futures $129、Universal $179。提前续费会从当前到期日之后增加30天。到期后禁止新开仓；已有仓位不会被直接丢弃，会继续现有风险管理。

API 仅开启 Read + Trade，关闭 Withdraw。盈利不保证。
